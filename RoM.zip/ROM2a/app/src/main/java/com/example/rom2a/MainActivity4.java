package com.example.rom2a;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity4 extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pagetwo);
        Button btn1 = (Button) findViewById(R.id.msg);
        btn1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v)  {
                Toast.makeText(getBaseContext(), "Incorrect! Try Again" , Toast.LENGTH_SHORT ).show();
            }
        });
        Button next2 = (Button)findViewById(R.id.msg2);
        next2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ResultActivity();
            }
        });

            ImageButton next = findViewById(R.id.buttonplay2);
            next.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    ResultActivity();
                }
            });
        }
    public void ResultActivity() {
        Intent intent2 = new Intent(this, MainActivity5.class);
        startActivity(intent2);
    }
    }

