package com.example.rom2a;

import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Locale;

@SuppressWarnings("ALL")
public class MainActivity3 extends AppCompatActivity {
    private static final int REQUEST_CODE_SPEECH_INPUT = 1000;
//    TextView mTextTv;
    ImageButton mVoiceBtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pageone);
        Button btn1 = (Button) findViewById(R.id.msgf);
        btn1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v)  {
                Toast.makeText(getBaseContext(), "Incorrect! Try Again" , Toast.LENGTH_SHORT ).show();
            }
        });
        mVoiceBtn = findViewById(R.id.record);
//        mTextTv = findViewById(R.id.textTv);
        mVoiceBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                speak();
            }
        });
        Button next2 = (Button)findViewById(R.id.msgf2);
        next2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                NextActivity();
            }
        });
        ImageButton next = findViewById(R.id.buttonplay);
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NextActivity();
            }
        });
    }



    private void speak() {
        Intent intentr = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intentr.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intentr.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        intentr.putExtra(RecognizerIntent.EXTRA_PROMPT,"Speak the text");

        try{
            startActivityForResult(intentr, REQUEST_CODE_SPEECH_INPUT);
        }
        catch (Exception e){
            Toast.makeText(this, ""+e.getMessage(),Toast.LENGTH_SHORT);
        }
    }

    @Override
    protected void  onActivityResult(int requestCode, int resultCode, @Nullable Intent data){
        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode){
            case REQUEST_CODE_SPEECH_INPUT:{
                if(resultCode == RESULT_OK && null != data){
                    ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
//                       mTextTv.setText(result.get(0))
                }
                break;
            }
        }
    }

    public void NextActivity() {
        Intent intent2 = new Intent(this, MainActivity4.class);
        startActivity(intent2);
    }

}
